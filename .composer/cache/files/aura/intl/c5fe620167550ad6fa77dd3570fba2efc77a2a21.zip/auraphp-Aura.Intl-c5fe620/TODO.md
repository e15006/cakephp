- README examples for fallbacks

- README examples for all-at-once configuration

- More specific exception classes

* * *

- Rename "Catalog" to "Package"

- Rename "Package" to "PackageLocator"

- Create a Package description object that has properties for messages,
  formatter, and fallback

- Create a PackageFactory
