<?php
/**
 * Loader
 */
$loader->add('Aura\Intl\\', dirname(__DIR__) . DIRECTORY_SEPARATOR . 'tests');
