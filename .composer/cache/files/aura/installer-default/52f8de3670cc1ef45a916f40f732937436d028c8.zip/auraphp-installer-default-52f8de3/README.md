Default Installer for Aura System
=================================

Using this installer, all [Composer][] packages of `"type" : "aura-package"`
will be installed in the default location of
`vendor/vendor_name/package_name`.

Note that this is not an Aura package proper; it is designed for use directly
with Composer, and as such will be placed in `vendor` not `package`.

[Composer]: http://getcomposer.org/
[Aura system]: https://github.com/auraphp/system
