<?php

throw new \Exception('I shouldnt be run');
